#!/bin/bash

# Base firewall rules
sudo modprobe br_netfilter
sudo sysctl -p /etc/sysctl.conf
sudo /home/student/firewall_rules.sh

# External IP set up
sudo ip link set dev eth3 up
sudo ip addr add 128.8.238.72/24 brd + dev eth3
sudo ip addr add 128.8.238.91/24 brd + dev eth3
sudo ip addr add 128.8.238.123/24 brd + dev eth3
sudo ip addr add 128.8.238.136/24 brd + dev eth3
sudo ip addr add 128.8.238.217/24 brd + dev eth3

# Starting containers
sudo lxc-start container1
sudo lxc-start container2
sudo lxc-start container3
sudo lxc-start container4
sudo lxc-start container5

# Call mitmNat script
sleep 10
sudo /home/student/mitmNAT.sh container1 128.8.238.72 1111
sudo /home/student/mitmNAT.sh container2 128.8.238.91 1112
sudo /home/student/mitmNAT.sh container3 128.8.238.123 1113
sudo /home/student/mitmNAT.sh container4 128.8.238.136 1114
sudo /home/student/mitmNAT.sh container5 128.8.238.217 1115