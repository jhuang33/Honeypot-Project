#!/bin/bash

# Define the base name and directory
file_base="$2.log"
dir="$2"

# Start with an increment of 1
counter=1

# Loop to find the next available file name
while [[ -e "$dir/$file_base$counter" ]]; do
    ((counter++))
done

# Move or copy your file to the target directory with the incremented name
mv ~/$1.log "$dir/$file_base$counter"
