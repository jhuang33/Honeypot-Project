#!/bin/bash

# Define IP pool and container pool
CONFIG_POOL=("snap0" "snap1" "snap2" "snap3")
IDLE_LIMIT=300
LIMIT=1800

# Function to randomly assign configurations to containers on recycle
if [[ "$1" == container1 ]]
then
  IP=128.8.238.72
  MITMPORT=1111
fi
if [[ "$1" == container2 ]]
then
  IP=128.8.238.91
  MITMPORT=1112
fi
if [[ "$1" == container3 ]]
then
  IP=128.8.238.123
  MITMPORT=1113
fi
if [[ "$1" == container4 ]]
then
  IP=128.8.238.136
  MITMPORT=1114
fi
if [[ "$1" == container5 ]]
then
  IP=128.8.238.217
  MITMPORT=1115
fi

assign_random_config() {
  RandConfig=$(shuf -e -n1 "${CONFIG_POOL[@]}")
}

# Function to recycle the container (restore snapshot and apply new config)
recycle_container() {
    assign_random_config
    ./importFile.sh $1 $RandConfig
    sudo iptables --table nat --delete PREROUTING --source 0.0.0.0/0 --destination $IP --protocol tcp --dport 22 --jump DNAT --to-destination 127.0.0.1:$MITMPORT
    sudo iptables --table nat --delete POSTROUTING --source "`sudo lxc-info -n $1 -iH`" --destination 0.0.0.0/0 --jump SNAT --to-source $IP
    sudo iptables --table nat --delete PREROUTING --source 0.0.0.0/0 --destination $IP --jump DNAT --to-destination "`sudo lxc-info -n $1 -iH`"
    sudo ip addr delete $IP/24 brd + dev eth3
    forever_index=$(sudo forever list | grep "mitm.js -n $1" | awk '{print $2}' | tr -d '[]')
    sudo forever stop $forever_index
    sudo lxc-stop -n $1
    sudo lxc-snapshot -n $1 -r "$RandConfig" # Restore random config snapshot to container
    sudo lxc-start -n $1
    sleep 5
    ./mitmNAT.sh $1 $IP $MITMPORT
    rm $1.txt
    echo "Recycling Container"
    exit 0
}

if [[ -f $1.txt ]]
then
  current_time=`date +%s`
  start_time=`tail -n 1 $1.txt`
  time_difference=$((current_time - start_time))
  last_command_time=$(date -d "$(cat $1.log | colrm 1 11 | colrm 9 | tail -n 1)" +%s)
  idle_time_difference=$((current_time - last_command_time))
  if [[ $time_difference -ge $LIMIT ]]
  then
    echo "30 minutes has passed"
    recycle_container $1
  fi
  if [[ $idle_time_difference -ge $IDLE_LIMIT ]]
  then
    echo "5 minutes idle"
    recycle_container $1
  fi
  if [[ `cat $1.log | grep "OpenSSH server closed connection" -c` -ge 1 ]]
  then
    echo "Attacker left"
    recycle_container $1
  fi
else
  if [[ `cat $1.log | grep "Attacker\ authenticated" -c` -ge 1 ]]
  then
    echo `date +%s` > $1.txt
  else
    echo "Attacker has not entered"
    exit 0
  fi
fi
exit 0